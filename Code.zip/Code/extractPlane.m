function slice = extractPlane(volData, coeff, ctr) 

sz = size(volData);

% get vertices
VertArray = zeros(6, 3);
for idx=0:7
   vertArray(idx+1, :) = de2bi(idx, 3, 'left-msb') .* sz;
end

% get projection of the cube vertices on the 2nd and 3rd PCs
xDistArray = zeros(1, 6);
yDistArray = zeros(1, 6);

% dist = (pt - ctr).v, where, pt is a vertex of the cube, ctr is the center
% of the data we got after binarization, and v is the unit vector in the
% direction of the axis (in this case, the 2nd and 3rd PCs).
for idx = 1:8
   pt = vertArray(idx, :);
   xDistArray(idx) = (pt - ctr)*coeff(:, 2);
   yDistArray(idx) = (pt - ctr)*coeff(:, 3);
end

% get pca image
xDistArray = round(xDistArray);
yDistArray = round(yDistArray);
minX = min(xDistArray);
maxX = max(xDistArray);
minY = min(yDistArray);
maxY = max(yDistArray);
slice = zeros(maxX-minX, maxY-minY);

for xDist = minX:maxX
    for yDist = minY:maxY
        xIdx = xDist - minX + 1;
        yIdx = yDist - minY + 1;
        volIdx = round(ctr + xDist*coeff(:, 2)' + yDist*coeff(:, 3)');
        if volIdx(1) > 0 && volIdx(2) > 0 && volIdx(3) > 0 && volIdx(1) <= sz(1) && volIdx(2) <= sz(2) && volIdx(3) <= sz(3)
            slice(xIdx, yIdx) = volData(volIdx(1), volIdx(2), volIdx(3));
        end
    end
end
