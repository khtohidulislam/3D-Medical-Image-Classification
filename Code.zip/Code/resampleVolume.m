
function volDataSamp = resampleVolume(volData, diInfo)

sz = size(volData);
sp = [diInfo.PixelSpacing; diInfo.SliceThickness];

nY = sz(2) * sp(2) / sp(1); % y dim after sampling
nZ = sz(3) * sp(3) / sp(1); % number of slices after sampling

if nY ~= sz(2) || nZ ~= sz(3)
    volDataSamp = imresize3(volData, [sz(1), nY, nZ]);
else
    volDataSamp = volData;
end

