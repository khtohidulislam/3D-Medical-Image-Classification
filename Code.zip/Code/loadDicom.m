clear all;
close all;
className = 'N';
dataDir = ['E:\Databases\Dicom Database\100 Dicom Database\', className, '\'];
saveDir = 'E:\3D Extraction\New code\2D Images\Taolin Jin\Abdomen';

dirs = dir(dataDir);
dirNames = {dirs.name};
dirNames = dirNames(3:end); % remove the 2 default directories
nDirs = numel(dirNames);

for dIdx = 1:nDirs
    disp(['Processing ', dataDir, dirNames{dIdx}]);
    
    dicomDir = [dataDir, dirNames{dIdx}, '\'];
    dirFiles = dir(dicomDir);
    fileNames = {dirFiles.name};
    fileNames = fileNames(3:end); % remove the 2 default directories
    nFiles = numel(fileNames);

    diInfo = dicominfo([dicomDir, fileNames{1}], 'UseDictionaryVR', true);
    volume = zeros(diInfo.Rows, diInfo.Columns, nFiles);

    for fIdx = 1:nFiles
        diInfo = dicominfo([dicomDir, fileNames{fIdx}], 'UseDictionaryVR', true);
        sliceNo = diInfo.InstanceNumber;
        slice = dicomread([dicomDir, fileNames{fIdx}]);
        volume(:, :, sliceNo) = slice;
    end

    maxVol = max(volume(:));
    minVol = min(volume(:));
    volume = 255*(volume-minVol)/(maxVol-minVol);
    %volume = imresize3(volume, [128, 128, 27]);
    
    volume = resampleVolume(volume, diInfo); % to see in real size
    % For PCA
    %slice =  extractSlicePCA(volume);
    %For Symmetry
    sz = size(volume);
    thresh = multithresh(volume(:), 2);
    ind = intersect(find(volume > thresh(1)), find(volume < thresh(2)));
  
    [x, y, z] = ind2sub(size(volume), ind);
    A = [x, y, z];
    ptCloud = pointCloud(A);
    P = ptCloud.Location;

    [planePoints, perpVectors, ~, scale] = symmetryViaRegistration3D(P);
    p = planePoints(:,1);
    v = perpVectors(:,1);
    slice = extractPlane(volume, perpVectors, mean(P));
    
    %imwrite(uint8(255*mat2gray(slice)), [saveDir, className, num2str(dIdx), '.png']);
    imwrite(uint8(255*mat2gray(slice)), [saveDir, dirNames{dIdx}, '.png']);
end